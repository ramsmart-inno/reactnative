/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React from 'react';
import {
  StyleSheet,
  Text,
  View,
} from 'react-native';

import ColumnComponent from './Components/ColumnComponent';
import RowComponent from './Components/RowComponent';
import TextComponent from './Components/TextComponent';
import InputTextComponent from './Components/InputTextComponent';
import ImageComponents from './Components/ImageComponents';
import ButtonComponent from './Components/ButtonComponent';
import BoxComponent from './Components/BoxHorComponent';
import ScrollViewComponent from './Components/ScrollViewComponent';
import FlatListViewComponent from './Components/FlatListViewComponent';
import LoadingComponent from './Components/LoadingComponent';
import SwitchComponent from './Components/SwitchComponent';
import ImageBackgroundComponent from './Components/ImageBackgroundComponent';
import SafeAreaComponent from './Components/SafeAreaComponent';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from './screens/HomeScreen';
import ProfileScreen from './screens/ProfileScreen';
import SettingsScreen from './screens/SettingsScreen';
import PdfViewer from './screens/pdfviewer_component';
import SignatureScreen from './screens/SignatureScreen';
import ModifyPdf from './screens/ModifyPDF';
import PDFExample from './screens/PDFExample';

const Stack = createNativeStackNavigator();

function App(): React.JSX.Element {

  return (
      // <ColumnComponent/>
      // <RowComponent/>
    // <TextComponent/>
    // <InputTextComponent/>
    // <ImageComponents />
    // <ButtonComponent/>
    // <BoxComponent/>
    // <ScrollViewComponent/>
    // <FlatListViewComponent/>
    // <LoadingComponent/>
    // <SwitchComponent/>
    // <ImageBackgroundComponent/>
    // <SafeAreaComponent/>
    <NavigationContainer>
      <Stack.Navigator initialRouteName='Home'>
        <Stack.Screen name="Home" component={HomeScreen}/>
        <Stack.Screen name="Profile" component={ProfileScreen}/>
        <Stack.Screen name="Settings" component={SettingsScreen}/>
        <Stack.Screen name="PDFComponent" component={PdfViewer}/>
        <Stack.Screen name="Signature" component={SignatureScreen}/>
        <Stack.Screen name="Modify" component={ModifyPdf}/>
        <Stack.Screen name="PDFExample" component={PDFExample}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
