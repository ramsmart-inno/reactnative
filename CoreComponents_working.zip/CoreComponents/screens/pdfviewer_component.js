/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React, { useEffect } from 'react';
import Pdf from 'react-native-pdf';
import {
    StyleSheet,
    Dimensions,
    View,
    TouchableOpacity,
} from 'react-native';
import { saveData, retrieveData } from './prefs';


// export default class PdfViewer extends React.Component {
//   render() {
//       const source = { uri: 'http://samples.leanpub.com/thereactnativebook-sample.pdf', cache: true };
//       //const source = require('./test.pdf');  // ios only
//       //const source = {uri:'bundle-assets://test.pdf' };
//       //const source = {uri:'file:///sdcard/test.pdf'};
//       //const source = {uri:"data:application/pdf;base64,JVBERi0xLjcKJc..."};
//       //const source = {uri:"content://com.example.blobs/xxxxxxxx-...?offset=0&size=xxx"};
//       //const source = {uri:"blob:xxxxxxxx-...?offset=0&size=xxx"};

//       return (
//           <View style={styles.container}>
//               <Pdf
//                   source={source}
//                   trustAllCerts={false}
//                   onLoadComplete={(numberOfPages,filePath) => {
//                       console.log(`Number of pages: ${numberOfPages}`);
//                   }}
//                   onPageChanged={(page,numberOfPages) => {
//                       console.log(`Current page: ${page}`);
//                   }}
//                   onPageSingleTap={(page, x, y) => {
//                     console.log(`tap: ${page}`);
//                     console.log(`x: ${x}`);
//                     console.log(`y: ${y}`);
//                   }}
//                   onError={(error) => {
//                       console.log(error);
//                   }}
//                   onPressLink={(uri) => {
//                       console.log(`Link pressed: ${uri}`);
//                   }}
//                   style={styles.pdf}/>
//           </View>
//       )
//   }
// }

export default function PdfViewer({ navigation }) {

    useEffect(() => {
        const { height, width } = Dimensions.get('screen');
        console.log('Screen height:', height);
        console.log('Screen width:', width);
    }, []);

    const source = { uri: 'https://www.sldttc.org/allpdf/21583473018.pdf', cache: false };
    // const source = {uri:'file:///data/user/0/com.corecomponents/files/sample12.pdf'};

    const handlePress = (event) => {
        const { locationX, locationY } = event.nativeEvent;
        console.log('Tap position:', { x: locationX, y: locationY });
    };

    const onLayout = (event) => {
        const { width, height } = event.nativeEvent.layout;
        // setViewLayout({ width, height });
        console.log('On Layout width and height', height, width);
        const { locationX, locationY } = event.nativeEvent;
        console.log('Tap position:', { x: locationX, y: locationY });
    };

    return (
        <View style={styles.container}>
            {/* <TouchableOpacity onPress={handlePress}> */}
                <View style={{ backgroundColor: 'lightblue' }}
                    onLayout={onLayout}>
                    <Pdf
                        source={source}
                        trustAllCerts={false}
                        onLoadComplete={(numberOfPages, filePath, a) => {
                            console.log(`Number of pages: ${numberOfPages}`);
                            console.log(`Page Size: ${a.height} ${a.width}`);
                        }}

                        // singlePage={true}
                        // enablePaging={true}
                        onPageChanged={(page, numberOfPages) => {
                            console.log(`Current page: ${page.Dimensions}`);
                        }}
                        minScale={1.0}
                        maxScale={1.0}
                        scale={1.0}
                        spacing={0}
                        // spacing={0}
                        onPageSingleTap={(page, x, y) => {
                            console.log(`tap: ${page}`);
                            console.log(`x: ${x}`);
                            console.log(`y: ${y}`);
                            saveData('@tappedPage', `${page}`);
                            saveData('@tappedPageX', `${x}`);
                            saveData('@tappedPageY', `${y}`);
                            // const { locationX, locationY } = event.nativeEvent;
                            // console.log('Tap position:', { x: locationX, y: locationY });
                        }}
                        onError={(error) => {
                            console.log(error);
                        }}
                        onPressLink={(uri) => {
                            console.log(`Link pressed: ${uri}`);
                        }}
                        onLoadProgress={(d) => {
                            console.log(`Progress : ${d.toFixed}`)
                        }}
                        style={styles.pdf} />
                </View>
            {/* </TouchableOpacity> */}
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginTop: 25,
    },
    pdf: {
        flex: 1,
        width: Dimensions.get('window').width,
        height: Dimensions.get('window').height,
    }
});
