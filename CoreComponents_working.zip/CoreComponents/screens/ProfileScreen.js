import { StyleSheet, Text, View, Button } from "react-native";

export default function ProfileScreen({ navigation }) {
    return (
        <View style={styles.container}>
            <Text style={styles.text}>Profile Screen</Text>
            <Button title="Go to Settings" onPress={() => navigation.navigate("Settings")} />
            <View style={{height:12}}/>
            <Button title="Go to PDF Viewer" onPress={() => navigation.navigate("PDFComponent")} />
            <View style={{height:12}}/>
            <Button title="Go to Signature Pad" onPress={() => navigation.navigate("Signature")} />
            <View style={{height:12}}/>
            <Button title="Go to Modify PDF" onPress={() => navigation.navigate("Modify")} />
            
            <View style={{height:12}}/>
            <Button title="Go to PDF Example" onPress={() => navigation.navigate("PDFExample")} />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center"
    },
    text: {
        fontSize: 24,
        fontWeight: "bold",
        marginBottom: 16
    }
})