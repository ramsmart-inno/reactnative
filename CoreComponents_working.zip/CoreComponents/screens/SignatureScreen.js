import React, {useEffect} from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';
import SignatureCapture from 'react-native-signature-capture';

export default function SignatureScreen( {navigation} ) {
  let signatureRef = null;

  const saveSignature = () => {
    if (signatureRef) {
      signatureRef.saveImage();
      navigation.navigate('Profile');
    }
  };

  const resetSignature = () => {
    if (signatureRef) {
      signatureRef.resetImage();
    }
  };

  const onSignatureSave = (result) => {
    console.log(result);
    // Handle the saved signature image here
  };

  return (
    <View style={styles.container}>
      <SignatureCapture
        ref={(ref) => (signatureRef = ref)}
        onSaveEvent={onSignatureSave}
        style={styles.signature}
        showBorder={true}
        showNativeButtons={false}
        showTitleLabel={false}
        backgroundColor="#ffffff"
        strokeColor="#000000"
        minStrokeWidth={4}
        maxStrokeWidth={4}
        viewMode={'portrait'}
        // width={400}
      />
      <View style={styles.buttonContainer}>
        <Button title="Save" onPress={saveSignature} />
        <View style={{width:12}}/>
        <Button title="Reset" onPress={resetSignature} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  signature: {
    // flex: 1,
    borderColor: '#000000',
    borderWidth: 1,
    height: '50%',
    width: '100%'
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 20,
  },
});

