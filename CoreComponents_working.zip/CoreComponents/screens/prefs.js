import AsyncStorage from '@react-native-async-storage/async-storage';

export const saveData = async (key, value) => {
  try {
    await AsyncStorage.setItem(key, value);
    console.log('Data saved successfully.');
    console.log('Saved data key and Value', key, value);
  } catch (error) {
    console.error('Error saving data:', error);
  }
};

// Retrieving data
export const retrieveData = async (key) => {
    try {
      const value = await AsyncStorage.getItem(key);
      if (value !== null) {
        console.log('Retrieved value:', value);
      } else {
        console.log('No data found.');
      }
    } catch (error) {
      console.error('Error retrieving data:', error);
    }
  };
  
  // Clearing data
  export const clearData = async () => {
    try {
      await AsyncStorage.clear();
      console.log('Data cleared successfully.');
    } catch (error) {
      console.error('Error clearing data:', error);
    }
  };