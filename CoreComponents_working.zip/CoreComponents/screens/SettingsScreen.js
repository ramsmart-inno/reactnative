import { StyleSheet, Text, View, Button } from "react-native";

export default function SettingsScreen({navigation}) {
    return (
        <View style={styles.container}>
            <Text style={styles.text}>Settings Screen</Text>
            <Button title="Go to Profile" onPress={ () => navigation.navigate("Profile")}/>
        </View>
    );
} 

const styles = StyleSheet.create({
    container: {
        flex:1,
        alignItems:"center",
        justifyContent:"center"
    },
    text:{
        fontSize:24,
        fontWeight:"bold",
        marginBottom:16
    }
})