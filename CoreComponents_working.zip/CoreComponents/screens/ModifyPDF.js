import { StyleSheet, Text, View, Button } from "react-native";
import PDFLib, { PDFDocument, PDFPage } from '@shogobg/react-native-pdf';



export default function ModifyPdf({ navigation }) {


    async function generatePdfWithText() {
        try {

            // const pdfUrl = 'https://www.sldttc.org/allpdf/21583473018.pdf';

            // const existingPdfBytes = await fetch(pdfUrl).then(res => res.arrayBuffer())
            // Load a PDFDocument from the existing PDF bytes
            const docsDir = await PDFLib.getDocumentsDirectory();
            console.log(docsDir);

            const page1 = PDFPage
                .create()
                .drawText('This is a modification on the first page!', {
                    x: 5,
                    y: 235,
                    color: '#F62727',
                })
                .drawRectangle({
                    x: 150,
                    y: 150,
                    width: 50,
                    height: 50,
                    color: '#81C744',
                });
                const pdfPath = `${docsDir}/sample12.pdf`;

                PDFDocument
                  .create(pdfPath)
                  .addPages(page1)
                  .write() // Returns a promise that resolves with the PDF's path
                  .then(path => {
                    console.log('PDF created at: ' + path);
                    // Do stuff with your shiny new PDF!
                  });
        } catch (error) {
            console.error('Error generating PDF:', error);
            return null;
        }
    }

    // Example usage:
    // const existingPdfBytes = ... (load existing PDF bytes)
    // const modifiedPdfBytes = await generatePdfWithText(existingPdfBytes);
    // console.log('Modified PDF bytes:', modifiedPdfBytes);


    return (
        <View style={styles.container}>
            <Text style={styles.text}>Modify PDF Screen</Text>
            <Button title="Save Modified PDF" onPress={() => generatePdfWithText()} />


        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center"
    },
    text: {
        fontSize: 24,
        fontWeight: "bold",
        marginBottom: 16
    }
})