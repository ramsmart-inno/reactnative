import { Alert, Button, StyleSheet, View } from "react-native";

const ButtonComponent = () => {
    return (
        <View style={styles.container}>
            <Button
            color={'#841543'}
                onPress={() => console.log('Pressed')}
                title="Button" />
            <View style={{ height: 8 }} />
            <Button
            color={'#516909'}
                onPress={() => Alert.alert('Click Me')}
                title="Click Me" />
        </View>
    )
}

export default ButtonComponent;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 16
    },
    btn: {
        width: '100%'
    }
})