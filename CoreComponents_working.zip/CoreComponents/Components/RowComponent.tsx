import { StyleSheet, Text, View } from "react-native";

const RowComponent = () => {
    return (
        <View style = {styles.rootContainer}>
            <View style ={styles.container}>
            <Text style={styles.text}>1</Text>
            <Text style={styles.text}>2</Text>
            <Text style={styles.text}>3</Text>
            <Text style={styles.text}>4</Text>
            <Text style={styles.text}>5</Text>
            <Text style={styles.text}>6</Text>
            <Text style={styles.text}>7</Text>
        </View>
        <View style ={styles.container}>
            <Text style={styles.text}>1</Text>
            <Text style={styles.text}>2</Text>
            <Text style={styles.text}>3</Text>
            <Text style={styles.text}>4</Text>
            <Text style={styles.text}>5</Text>
            <Text style={styles.text}>6</Text>
            <Text style={styles.text}>7</Text>
        </View>
        <View style ={styles.container}>
            <Text style={styles.text}>1</Text>
            <Text style={styles.text}>2</Text>
            <Text style={styles.text}>3</Text>
            <Text style={styles.text}>4</Text>
            <Text style={styles.text}>5</Text>
            <Text style={styles.text}>6</Text>
            <Text style={styles.text}>7</Text>
        </View>
        <View style ={styles.container}>
            <Text style={styles.text}>1</Text>
            <Text style={styles.text}>2</Text>
            <Text style={styles.text}>3</Text>
            <Text style={styles.text}>4</Text>
            <Text style={styles.text}>5</Text>
            <Text style={styles.text}>6</Text>
            <Text style={styles.text}>7</Text>
        </View>
        <View style ={styles.container}>
            <Text style={styles.text}>1</Text>
            <Text style={styles.text}>2</Text>
            <Text style={styles.text}>3</Text>
            <Text style={styles.text}>4</Text>
            <Text style={styles.text}>5</Text>
            <Text style={styles.text}>6</Text>
            <Text style={styles.text}>7</Text>
        </View>
        <View style ={styles.container}>
            <Text style={styles.text}>1</Text>
            <Text style={styles.text}>2</Text>
            <Text style={styles.text}>3</Text>
            <Text style={styles.text}>4</Text>
            <Text style={styles.text}>5</Text>
            <Text style={styles.text}>6</Text>
            <Text style={styles.text}>7</Text>
        </View>
        </View>
    )
}

export default RowComponent;


const styles = StyleSheet.create({
    rootContainer : {
        flex: 1,
    },
    container : {
        flex: 1,
        marginTop:40,
        justifyContent: 'center',
        backgroundColor: '#09d0e6df',
        alignItems: 'center',
        flexDirection: 'row'
    },
    text: {
        fontSize : 24,
        fontWeight : 'bold',
    }
})