/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React from 'react';
import {
  StyleSheet,
  Text,
  View,
} from 'react-native';

import {name as appName} from '../app.json';

export const name = "This is a View Component"

export default function ViewCustomComponent(){

    return (
        <View style = {styles.container}>
            <Text>{name}</Text>
            <Text>{appName}</Text>
            <View style={{height:8}}/>
            <View style={{height:100, width: 100, backgroundColor:'red'}}/>
            <View style={{height:8}}/>
            <View style={{height:100, width: '100%', backgroundColor:'green'}}/>
        </View>
      );

};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor: '#09d0e6df',
        alignItems: 'center'
    }
})
