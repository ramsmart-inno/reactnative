import { View, Image, StyleSheet , Platform} from "react-native";

const ImageComponents = () => {
    return (
        <View style={styles.container}>
            <Image
            source={require('../assets/logo.jpeg')}
            style={styles.smallLogo}
            />
            <View style={{height: 8}}/>
            <Image
            source={{uri:'https://picsum.photos/200/300'}}
            style={styles.logo}
            resizeMode="cover"
            defaultSource={require('../assets/logo.jpeg')}
            onLoadStart={() => console.log("Start")}
            onLoadEnd={() => console.log("End")}
            />
        </View>
    )

}

export default ImageComponents;

const styles =  StyleSheet.create({
    container:{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding:16
    },
    smallLogo :{
        height: 200,
        width: 200,
        borderRadius: 150,
        borderColor: 'red',
        borderWidth: 1
    },
    logo:{
        height:300,
        width: Platform.OS  === 'android' ? 320 :  100
    }

})