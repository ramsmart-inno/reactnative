import { SafeAreaView, StyleSheet, Text, View } from "react-native";

const SafeAreaComponent = () => {
    return (
        // <SafeAreaView style={styles.container}>
            <View style={styles.container}>
                <Text>Safe Area Widget Testing</Text>
            </View>
        // </SafeAreaView>

    )
}

export default SafeAreaComponent;

const styles = StyleSheet.create({
    container: {
        flex: 1,
    }
})