import { ImageBackground, StyleSheet, Text, View } from "react-native";

const ImageBackgroundComponent = () => {
    return (
        <ImageBackground
        
        source={require('../assets/logo.jpeg')}
        style={styles.image}
        resizeMode="cover"
        >
            <View style={styles.container}>
                <Text style={styles.text}> Hello World!</Text>
            </View>
        </ImageBackground>
    )
}

export default ImageBackgroundComponent;

const styles = StyleSheet.create({
    container:{
        flex:1,
        justifyContent:'center',
        alignItems:'center'
    },
    image:{
        flex:1
    },
    text:{
        fontSize:14,
        fontWeight:'bold'
    }
}) 