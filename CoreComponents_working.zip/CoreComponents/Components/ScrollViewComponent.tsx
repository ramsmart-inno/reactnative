import { ScrollView, StyleSheet, Text, View } from "react-native";
import BoxComponent from "./BoxComponent";
import BoxHorComponent from "./BoxHorComponent";

const ScrollViewComponent = () => {
    return (
        <View>
            <ScrollView style={styles.container}>
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />
                <BoxComponent />
                <View style={{ height: 8 }} />

            </ScrollView>
            <ScrollView style={styles.containerHor} horizontal={true}>
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />
                <BoxHorComponent />
                <View style={{ width: 8 }} />

            </ScrollView>
        </View>


    )
}

export default ScrollViewComponent;


const styles = StyleSheet.create({
    container: {
        padding: 10,
        height: 500
    },

    containerHor: {
        padding: 10,
        height: 500,
    },

})