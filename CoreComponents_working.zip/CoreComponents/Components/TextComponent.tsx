import { Text, StyleSheet, View } from "react-native";

const TextComponent = () => {
    return (
        <View style={styles.container}>
             <Text style={styles.baseText}>This is a Text Component</Text>
             <Text style={styles.baseText}>World of Events</Text>
       
       <Text style={styles.baseText}>
        This !.... 
       <Text style={styles.baseText1}>Hi</Text>
       
       <Text style={styles.baseText1}> Welcome</Text>
       <Text style={styles.baseText1}> Text Component</Text>
       
       
       </Text>
        </View>
         )
}

export default TextComponent;

const styles = StyleSheet.create({
    baseText: {
        fontFamily: 'Cochin',
        color:'black',
        fontSize: 24
    },

    baseText1: {
        color:'red',
        fontSize: 20
    },
    container:{
        flex:1,
        justifyContent: 'center',
        alignItems: 'center'
    }
})