import React, { useRef, useState } from "react";
import { StyleSheet, Text, TextInput, View } from "react-native";

const InputTextComponent = () => {
    const [name, setName] = useState('');
    const [age, setAge] = useState('0');
    const [bio, setBio] = useState('');
    const ageRef = useRef<TextInput>(null);
    const bioRef = useRef<TextInput>(null);

    return (
        <View style={styles.container}>
            <Text>{name}</Text>
            <View style={{ height: 8 }} />
            <TextInput style={styles.input}
                placeholder="Enter some input"
                autoFocus={true}
                keyboardType="default"
                returnKeyType="next"
                value={name}
                onChangeText={setName}
                blurOnSubmit={false}
                onSubmitEditing={() => { 
                    if (ageRef.current) {
                        ageRef.current.focus();
                    }
                }}
            />
            <View style={{ height: 8 }} />

            <TextInput style={styles.input}
                placeholder="Enter your age"
                // autoFocus={true}
                inputMode="numeric"
                // keyboardType="numeric"
                returnKeyType="next"
                // defaultValue="Name"
                value={age}
                onChangeText={setAge}
                ref={ageRef}
                onSubmitEditing={() => { 
                    if (bioRef.current) {
                        bioRef.current.focus();
                    }
                }}
            />
                        <View style={{ height: 8 }} />
            <TextInput style={styles.inputMultiline}
                placeholder="Enter your bio"
                // autoFocus={true}
                keyboardType='default'
                returnKeyType="next"
                multiline={true}
                numberOfLines={5}
                // defaultValue="Name"
                value={bio}
                onChangeText={setBio}
                ref={bioRef}
            />
        </View>


    )
}

export default InputTextComponent;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
        justifyContent: 'center',
        backgroundColor: '#fff',
        alignItems: 'center'
    },
    input: {
        borderWidth: 1,
        borderColor: '#544d4d',
        borderRadius: 8,
        padding: 8,
        width: '100%',
        height: 54
    },
    inputMultiline: {
        borderWidth: 1,
        borderColor: '#544d4d',
        borderRadius: 8,
        padding: 8,
        textAlignVertical:'top',
        width: '100%',
        // height: 108,
    }

})