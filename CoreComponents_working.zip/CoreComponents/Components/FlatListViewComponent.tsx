import { useState } from "react";
import { StyleSheet, Text, View, FlatList, TouchableOpacity } from "react-native";

const FlatListViewComponent = () => {
    function onRefresh(){
        console.log("Call Refresh");


            setRefresh(true);
            
    

        setTimeout(() => {
            setRefresh(false);
            console.log("Call Refresh Completed");
        }, 1000)
      
    }

    const DATA = [
        {
            'id': '1',
            'title': 'First',
            'description': 'Hello First'
        },
        {
            'id':'2',
            'title': 'Second',
            'description': 'Hello Second'
        },
        {
            'id': '3',
            'title': 'Third',
            'description': 'Hello Third'
        },
    ]

    const [refresh, setRefresh] = useState(false);
    
    return (
        // <View 
        // >
        //     <FlatList
        //         data={[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}
        //         renderItem={({ item, index, separators }) =>
        //             <View style={styles.card}>
        //                 <Text>{item}</Text></View>} />
        
        ///Flat List Vertical
        // <FlatList
        //     style={{marginTop: 100}}
        //         data={DATA}
        //         renderItem={({ item, index, separators }) =>
        //             <TouchableOpacity
        //                 onPress={() => console.log(item.id)}
        //             ><View style={styles.card}>
        //                     <Text style={styles.title}>{item.title}</Text>
        //                     <Text style={styles.description}>{item.description}</Text>
        //                 </View></TouchableOpacity>}
        //                 keyExtractor={item => item.id}
        //                 refreshing={refresh}
        //                 onRefresh={onRefresh}
        //     />

            <FlatList
            style={{marginTop: 100}}
            horizontal={true}
                data={DATA}
                renderItem={({ item, index, separators }) =>
                    <TouchableOpacity
                        onPress={() => console.log(item.id)}
                    ><View style={styles.card}>
                            <Text style={styles.title}>{item.title}</Text>
                            <Text style={styles.description}>{item.description}</Text>
                        </View></TouchableOpacity>}
                        keyExtractor={item => item.id}
                        refreshing={refresh}
                        onRefresh={onRefresh}
            />
        // {/* </View> */}
    )
}

export default FlatListViewComponent;


const styles = StyleSheet.create({
    card: {
        backgroundColor: 'green',
        borderRadius: 20,
        padding: 8,
        margin: 8,
        height: 100,
        width:300
    },
    title: {
        fontSize: 18,
        fontWeight: 'bold'
    },
    description: {
        fontSize: 12
    }
})