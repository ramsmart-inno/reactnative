import { StyleSheet, Text, View } from "react-native";

const BoxHorComponent = () => {
    return (
        <View style = {styles.container}/>
    )
}

export default BoxHorComponent;


const styles = StyleSheet.create({
    container : {
        backgroundColor: 'red',
        height: 100,
        width: 100
    }
})