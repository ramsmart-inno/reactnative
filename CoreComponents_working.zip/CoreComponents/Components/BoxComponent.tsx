import { StyleSheet, Text, View } from "react-native";

const BoxComponent = () => {
    return (
        <View style = {styles.container}/>
    )
}

export default BoxComponent;


const styles = StyleSheet.create({
    container : {
        backgroundColor: 'red',
        height: 100,
        width: "100%"
    }
})