import { StyleSheet, Text, View } from "react-native";

const ColumnComponent = () => {
    return (
        <View style ={styles.container}>
            <Text style={styles.text}>1</Text>
            <Text style={styles.text}>2</Text>
            <Text style={styles.text}>3</Text>
            <Text style={styles.text}>4</Text>
            <Text style={styles.text}>5</Text>
            <Text style={styles.text}>6</Text>
            <Text style={styles.text}>7</Text>
        </View>
    )
}

export default ColumnComponent;


const styles = StyleSheet.create({
    container : {
        flex: 1,
        justifyContent: 'space-around',
        backgroundColor: '#09d0e6df',
        alignItems: 'flex-start',
        flexDirection: 'column'
    },
    text: {
        fontSize : 24,
        fontWeight : 'bold',
        color: 'black'
    }
})