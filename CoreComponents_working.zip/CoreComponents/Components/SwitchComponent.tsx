import { useState } from "react";
import { StyleSheet, Switch, View } from "react-native";

const SwitchComponent = () => {

    const [isEnabled, setIsEnabled] = useState(false);

    function toggleSwitch(){
        setIsEnabled(previousState => !previousState);
    }

    return (
        <View style={styles.container}>
            <Switch value={isEnabled} onValueChange={toggleSwitch}/>
        </View>
    )
}

export default SwitchComponent;

const styles = StyleSheet.create({
    container : {
        flex:1,
        padding:16,
        alignItems:'center',
        justifyContent: 'center',
    }
})