# PDF Editor

This is a PDF Editor that allows you to add images and drawings to your pdf directly from your browser. This project is a react port of the svelte version [here](https://github.com/ShizukuIchi/pdf-editor) so most of the pdf generation and editing logic was lifted from there.
## Features

* Upload images
* Add drawings
* Move images around
* Delete miskaten images / drawings
* Cool UI :)