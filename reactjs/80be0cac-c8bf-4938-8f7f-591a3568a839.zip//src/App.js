import "./styles.css";
import FileViewer from "./FileViewer";

export default function App() {
  return (
    <div className="App">
      <h1>Pdf</h1>
      {/*<div className="cursor" />*/}
      <FileViewer />
    </div>
  );
}
